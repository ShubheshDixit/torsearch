# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['torsearch']
install_requires = \
['beautifulsoup4>=4.11.1,<5.0.0',
 'clipboard>=0.0.4,<0.0.5',
 'inquirer>=2.10.1,<3.0.0',
 'python-qbittorrent>=0.4.3,<0.5.0',
 'qbittorrent>=0.1.6,<0.2.0',
 'selenium>=4.6.0,<5.0.0',
 'tqdm>=4.64.1,<5.0.0',
 'typer>=0.7.0,<0.8.0']

setup_kwargs = {
    'name': 'torsearch',
    'version': '0.1.0',
    'description': 'Tor Seach helps you find torrents from various source like ThePirateBay, KickAss and YTS. Combined with a torrent client it can also help you download those torrent files.',
    'long_description': '',
    'author': 'Shrexy',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'py_modules': modules,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
